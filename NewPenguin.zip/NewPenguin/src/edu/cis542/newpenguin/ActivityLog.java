package edu.cis542.newpenguin;


import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class ActivityLog extends Activity {
	Messenger mService = null;	 
	boolean isBound = false;
	
	final Messenger mMessenger = new Messenger(new MainHandler());
	
	class MainHandler extends Handler{
		@Override
		public void handleMessage(Message msg){
			if(msg.what==ArduinoSocket.MESSAGE){
				Log.v("Service Outptut", msg.arg1 + "");
			}
			if(msg.what==ArduinoSocket.REPLY){
				receiveData(msg);
				
			}
		}


	}	
	private void receiveData(Message msg) {
		ListView view = (ListView) findViewById(R.id.listView1);
		ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this , android.R.layout.simple_list_item_1);
		view.setAdapter(arrayAdapter);
		arrayAdapter.addAll(msg.getData().getStringArray("log"));
	}
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.row);
        bindService(new Intent(this,ArduinoSocket.class), mConnection, BIND_AUTO_CREATE);
      

	}
	public void doorClick(View view){
		boolean doorUnlocked = ((ToggleButton) view).isChecked();
		if(doorUnlocked) sendCommand("~Lu00");
		else sendCommand("~Lu01");
	}
	public void sendCommand(String message){
		Message msg = Message.obtain(null, ArduinoSocket.UNBIND);
		msg.replyTo = mMessenger;
		Bundle data = new Bundle();
		data.putString("message", message);
		msg.setData(data);
		try {
			mService.send(msg);
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private ServiceConnection mConnection = new ServiceConnection(){
		public void onServiceConnected(ComponentName className, IBinder service) {
			mService = new Messenger(service);
			
			try {
			Message msg = Message.obtain(null, ArduinoSocket.BIND);
			msg.replyTo = mMessenger;
			mService.send(msg);
			isBound = true;
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				Toast.makeText(ActivityLog	.this, "Connection Failed" , Toast.LENGTH_SHORT).show();
			}
			Toast.makeText(ActivityLog.this, "Connected" , Toast.LENGTH_SHORT).show();
		}
		public void onServiceDisconnected(ComponentName className){
			
			mService = null;
			isBound = false;
			
		}
	};
}
