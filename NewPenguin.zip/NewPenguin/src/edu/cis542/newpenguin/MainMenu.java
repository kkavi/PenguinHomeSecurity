package edu.cis542.newpenguin;



import java.io.InputStream;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.ImageView;


public class MainMenu extends Activity {

	private static final int ACTIVITY_SysStatus = 1;
	private static final int HALF = 2;
	private static final int ACTIVITY_ViewPics = 3;
	private static final int ACTIVITY_EventLog = 4;
	private static final int ACTIVITY_TakePics = 5;
	
    
    DBAdapter adapter;
   // double time = 60;
    
    private ToggleButton toggleButton1;
    
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.mainmenu);
	    
        adapter = new DBAdapter(this);
        String rfid1 = "35000";
        long val1 =	adapter.insertDetails(rfid1);
        String rfid2 = "Okayfine";
    	 long val2 = adapter.insertDetails(rfid2);
    	 String rfid3 = "Kavi123";
         long val3 = adapter.insertDetails(rfid3);
       
         String rfid4 = "75000";
         long val4 = adapter.insertDetails(rfid3);
	    startService(new Intent(this, ArduinoSocket.class));
	}

	public void onCheckSystemClick(View v)
	{
	Intent i1 = new Intent(this,SystemStatus.class);
	startActivityForResult(i1,MainMenu.ACTIVITY_SysStatus);
	
	}
	
	public void onViewPicsClick(View v)
	{
		Intent intent = new Intent();
	    intent.setAction(Intent.ACTION_GET_CONTENT);
	    intent.addCategory(Intent.CATEGORY_OPENABLE);
	    intent.setType("image/*");
		startActivityForResult(intent, ACTIVITY_ViewPics);
	}
	
	public void onQuitClick(View v)
	{
	 finish();
			  
	}
	public void onEventlogClick(View view){
		Intent i2 = new Intent(this,ActivityLog.class);
		startActivity(i2);
	}
	

	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		InputStream stream = null;
	    if (requestCode == ACTIVITY_ViewPics && resultCode == Activity.RESULT_OK) {
	    	try {
	    		stream = getContentResolver().openInputStream(data.getData());
	    		Bitmap original = BitmapFactory.decodeStream(stream);
	    		((ImageView)findViewById(R.id.image_holder)).setImageBitmap(Bitmap.createScaledBitmap(original, 
	    				original.getWidth()/HALF, original.getHeight()/HALF, true));
	    	} catch (Exception e) {
	    		e.printStackTrace();
	    	}
	    	if (stream != null) {
	    		try {
	    			stream.close();
	    		} catch (Exception e) {
	    			e.printStackTrace();
	    		}
	    	}
		}
	    
	    if(requestCode == ACTIVITY_SysStatus)
	    {
	      Log.v("Back from","status");
	    }
	    
	    if(requestCode == ACTIVITY_EventLog)
	    {
	      Log.v("Back from","eventlog");
	    }
	}

	
}
