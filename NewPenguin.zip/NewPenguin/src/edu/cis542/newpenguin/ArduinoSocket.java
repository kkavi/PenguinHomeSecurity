package edu.cis542.newpenguin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.PortUnreachableException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.channels.IllegalBlockingModeException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.SynchronousQueue;




import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationCompat.Builder;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;
import android.app.Notification;

public class ArduinoSocket extends Service {
	static final int BIND = 1;
	static final int MESSAGE = 2;
	static final int UNBIND = 3;
	static final int REQUEST_DATA = 4;
	static final int REPLY = 5;
	static final int MOTION = 10;
	static final int DOOR = 11;
	static final int LIGHT = 12;
	static final int uniqueID = 87;
	private static final int UDP_SERVER_PORT = 8888;
    private static final int MAX_UDP_DATAGRAM_LEN = 1500;
    private static char eot = 4;
    private static char lightOff = 0;
    private static SynchronousQueue<String> toArduino;
    private static SynchronousQueue<Message> dataRequests;
	static ArrayList<Messenger> a;
	boolean isRunning;
	DBAdapter adapter;

	
    @Override
    public void onCreate() {
    	a = new ArrayList<Messenger>();
    	isRunning = true;
    	toArduino = new SynchronousQueue<String>();
    	dataRequests = new SynchronousQueue<Message>();
    	
    	
    	//createNotification(Calendar.getInstance().getTimeInMillis(),"Door is open");
    	Log.v("create", "carrier has arrived");
    	//Create new thread to read on socket
    	new Thread(new Runnable(){
    		public void run() {
    		      //Start the Server;
    			
    			runUdpClient("~Hu1"+eot);
    		  }
    	}).start();
    }
    @Override
	public void onDestroy(){
		isRunning = false;
		super.onDestroy();
		
	}
     static class ToArduinoHandler extends Handler{
		@Override
		public void handleMessage(Message msg){
			switch (msg.what){
				case BIND: 
					a.add(msg.replyTo);
					break;
				case MESSAGE:
					toArduino.add(msg.getData().getString("message"));
					break;
				case UNBIND: 
					a.remove(msg.replyTo);
					break;
				case REQUEST_DATA:
					dataRequests.add(msg);
				default: Log.v("failHandle", "handleFail");
			}
		}
	}

    @Override
    public int onStartCommand(Intent intent, int flags,int startId){
    	
    	handleCommand(intent);
    	return START_STICKY;
    }
 

	final Messenger mMessenger = new Messenger(new ToArduinoHandler());
    
    
    private boolean handleCommand(Intent intent) {
		if(intent.hasExtra("command")){
			//Enqueue the command
			Log.v("handled", "carrier has arrived");
			
			try {
				toArduino.put(intent.getStringExtra("command"));
			} catch (InterruptedException e) {
				Log.v("penguinerror","errorput");
			}

			return true;
		}
			return false;
	}

    public  void createNotification(String notiMsg){
		//Create the notification properties ie the text the alert and the image
    	
    		NotificationCompat.Builder testNotificationBuilder = new NotificationCompat.Builder(this)
    		.setSmallIcon(R.drawable.notification)
    		.setContentTitle("Warning")
    		.setContentText(notiMsg);
    		//Set where the notification will send you here it sends you to the Main Activity
    		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this,MainMenu.class), 0);
    		testNotificationBuilder.setContentIntent(pendingIntent);
    		//Create a notification manager to send off the notification
    		NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    		mNotificationManager.notify(uniqueID, testNotificationBuilder.build());
    	}
    	
    private void createNotification(long when,String data){
		
		Bitmap largeIcon = BitmapFactory.decodeResource(getResources(),R.drawable.ic_launcher);
		int smalIcon =R.drawable.ic_launcher;
		Intent intent =new Intent(getApplicationContext(), MainMenu.class);
		intent.setData(Uri.parse("content://"+when));
		
		PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
		NotificationManager notificationManager =(NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE); 
				
		/*build the notification*/
		NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(
				getApplicationContext())
				.setWhen(when)
				.setContentText(data)
				.setContentTitle("Hey there")
				.setSmallIcon(smalIcon)
				.setAutoCancel(true)
				.setTicker("New Notification")
				.setLargeIcon(largeIcon)
				.setDefaults(Notification.DEFAULT_LIGHTS| Notification.DEFAULT_VIBRATE| Notification.DEFAULT_SOUND)
				.setContentIntent(pendingIntent);
		
		/*Create notification with builder*/
		Notification notification=notificationBuilder.build();
		
		/*sending notification to system.Here we use unique id (when)for making different each notification
		 * if we use same id,then first notification replace by the last notification*/
		notificationManager.notify((int) when, notification);
	}

	
	
	
	private void runUdpClient(String udpMsg) {
		Log.v("run", "carrier has arrived");
		InetAddress arduinoAddress = getInetaddress();
		DatagramSocket ds2arduino = null;
		Message msgFromApp;
		try {
			ds2arduino = initalizeConnection(udpMsg,arduinoAddress);
		} catch (SocketException e1) {
			e1.printStackTrace();
		}
		while(isRunning){
			if((udpMsg = toArduino.poll()) !=null) 
				sendMessage(ds2arduino, udpMsg,arduinoAddress); // poll() returns the head of the queue
			
			try {
				receiveData(ds2arduino,arduinoAddress);
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if((msgFromApp = dataRequests.poll())!=null){
				try {
					reply(msgFromApp);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	private void reply(Message msgFromApp) throws RemoteException {
		Message msg = Message.obtain(null, REPLY);
		msg.replyTo = mMessenger;

		String dataRequested = msgFromApp.getData().getString("message");
		SharedPreferences systemStatus = getSharedPreferences("system",0);
		Bundle data = new Bundle();
		if(dataRequested.equals("motion")){
			data.putBoolean("motion", systemStatus.getBoolean("motion", false));
			msg.arg1 = MOTION;
			}
		if(dataRequested.equals("door")){
			data.putBoolean("door", systemStatus.getBoolean("door", false));
			msg.arg1 = DOOR;
		}
		if(dataRequested.equals("light")){
			msg.arg1 = LIGHT;
			msg.arg2 = systemStatus.getInt("light", 0);
		}
		msg.setData(data);
		msgFromApp.replyTo.send(msg);
	}
	private void receiveData(DatagramSocket ds2arduino, InetAddress arduinoAddress) {
			byte[] receiveData = new byte[1024];
			DatagramPacket packet2receive = new DatagramPacket(receiveData, receiveData.length);
			try {
			ds2arduino.receive(packet2receive);
			} catch(Exception ex)
			{
			System.out.println("Receive1: "+ex.toString());
			}
			String modifiedSentence = new String( packet2receive.getData(),0, packet2receive.getLength());
			Log.i("receive: ",modifiedSentence );
			if(modifiedSentence.length() >0) handleData(modifiedSentence, ds2arduino);
		
	}
	private void handleData(String modifiedSentence, DatagramSocket ds2arduino) {
		Log.v("Inside handleData","please");
		SharedPreferences systemStatus = getSharedPreferences("system",0);
		Editor systemStatusEditor = systemStatus.edit();
		//modifiedSentence ="~Rn2|KAV7KO|12345"+eot;
		if(modifiedSentence.substring(1, 4).equals("In0")){
			//notify state of light
			//Character ch = modifiedSentence.substring(4, 5)
			//Update Resource
			
			//Kavi
			char ch = modifiedSentence.charAt(4);
			double d = (100*ch)/255;
			String lightStr = Double.toString(d);
			systemStatusEditor.putString("lightSt", lightStr);
			
		}else if(modifiedSentence.substring(1, 4).equals("Ln0")){
			//Notification about the current State of the Lock
				
			if((modifiedSentence.charAt(4)=='1'))
				systemStatusEditor.putBoolean("door", true);
			else if((modifiedSentence.charAt(4)=='0'))
				systemStatusEditor.putBoolean("door", false);		
			//Get Lock Resource 
			//Update Resource 			
		}else if(modifiedSentence.substring(1, 4).equals("Lu0")){
			//Notification about a lock change				
			systemStatusEditor.putBoolean("door",!systemStatus.getBoolean("door", true));
			
		}else if(modifiedSentence.substring(1, 4).equals("Mn1")){
			//Notify Motion Detected
			createNotification("Motion Detected!");
			//Send out a notification to the user			
		}else if(modifiedSentence.substring(1, 4).equals("Mn2")){
			//Notify current State of motion Detection
			if((modifiedSentence.charAt(4)=='1')){
				systemStatusEditor.putBoolean("motion", true);
			}
			else if((modifiedSentence.charAt(4)=='0')){
				systemStatusEditor.putBoolean("motion", false);
			}
			
		}else if(modifiedSentence.substring(1, 4).equals("Rn1")){
			if(modifiedSentence.substring(4,5).equals("|")){
				//Change later to be more complex storage
				if(modifiedSentence.substring(5,6).equals("1"))
					Toast.makeText(this, "User is authorized",10).show();
				else if(modifiedSentence.substring(5,6).equals("0"))
					createNotification("RFID swipe detected. User is not authorized.\n");		
			}
			
		}else if(modifiedSentence.substring(1, 4).equals("Rn2")){
			//Notify List of all authorized ids
			int m=4;
			while(modifiedSentence.substring(m,m+1).equals("|")){
			 //String rfid1 = modifiedSentence.substring(m+1,m+6); 
			 //store in DB
				String rfid1 = "1010Kavi";
			 //long val = 
					 adapter.insertDetails(rfid1);
			 m=m+6;
			}
			
			
		}else if(modifiedSentence.substring(1, 4).equals("Sn0")){
			//List of all files
			
			//Store in App
			
			
		}else if(modifiedSentence.substring(1, 4).equals("Sd1")){
			//Notify
			createNotification("Intruder Detected");
			//Data transfer picture
			try {
				getPicture(ds2arduino);
			} catch(Exception ex)
			{
				System.out.println("Picture: "+ex.toString());
			}

			//Call Picture Data transfer Method
			
		}else if(modifiedSentence.substring(1, 4).equals("Sd2")){
			//File Transfer
			
			//Call File Transfer Method
			
		}
		systemStatusEditor.commit();
		//createNotification();
	}
		
	
	
	private void sendMessage(DatagramSocket ds2arduino, String udpMsg, InetAddress arduinoAddress) {
		DatagramPacket sp = new DatagramPacket(udpMsg.getBytes(), udpMsg.length(),
				arduinoAddress, UDP_SERVER_PORT);
		try{
			ds2arduino.send(sp);
		}
		catch(Exception ex)
		{
			System.out.println("Send2: "+ex.toString());
		}
		Log.i("send: ",udpMsg );	
	}
	private InetAddress getInetaddress(){
		InetAddress serverAddr = null;//= InetAddress.getByName("130.79.192.146");
		try{
			serverAddr = InetAddress.getByName("158.130.37.88"); //Arduino addressmd
		}catch(Exception ex){
			System.out.println("InetAddress: "+ex.toString());
		}
		return serverAddr;
	}
	private DatagramSocket initalizeConnection(String udpOpeningMessage,InetAddress serverAddress) throws SocketException {
		DatagramSocket ds = new DatagramSocket();
		Log.i("send", "okay1");
		DatagramPacket packet2send; //send packet
			//udpMsg = "Packet no " + i + "\n";
			packet2send = new DatagramPacket(udpOpeningMessage.getBytes(), udpOpeningMessage.length(),
					serverAddress, UDP_SERVER_PORT);
			try
			{
				ds.send(packet2send);
				Log.v("packet Sent", packet2send.getData().toString());
			}
			catch(Exception ex)
			{
				System.out.println("Send1: "+ex.toString());
			}
		return ds;
	}
	public IBinder onBind(Intent arg0) {
		Log.v("Bind", "bind");
		return mMessenger.getBinder();
	}
	
	private void getPicture(DatagramSocket ds) throws IOException {
		byte[] receiveData = new byte[512];
		DatagramPacket rp; // receive packet

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		while (true) {

			rp = new DatagramPacket(receiveData, receiveData.length);
			ds.receive(rp);
				
			byte b[] = rp.getData();
			String modifiedSentence = new String(b, 0, rp
					.getLength());

			if (!(modifiedSentence.charAt(0) == 'E' && modifiedSentence
					.charAt(2) == 'D')) {
				rp = new DatagramPacket(receiveData,
						receiveData.length);
				ds.receive(rp);

				byte c[] = rp.getData();
				String s = new String(c, 0, rp.getLength());
				
				// System.out.println(s);
				System.out.println("length = " + c.length);
				outputStream.write(c);

			} else {
				System.out.println("break activated");
				break;
			}
			
		}
	

	}
}

	
