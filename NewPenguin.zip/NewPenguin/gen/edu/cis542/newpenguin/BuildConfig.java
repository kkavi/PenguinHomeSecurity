/** Automatically generated file. DO NOT MODIFY */
package edu.cis542.newpenguin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}