package com.seethu.udpcommclient;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import com.seethu.udpcommclient.R;

import android.app.Activity; 
import android.os.Bundle;
import android.widget.TextView;

public class UdpClient extends Activity {
	/** Called when the activity is first created. */
	private TextView textView;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		textView = (TextView) findViewById(R.id.text1);
		runUdpClient();
		//finish();
	}

	//private static final int UDP_SERVER_PORT = 9931;
	private static final int UDP_SERVER_PORT = 8888;
	private void runUdpClient() {
		//String udpMsg = "hello world from UDP client " + UDP_SERVER_PORT; 
		String udpMsg;
		DatagramSocket ds = null;
		byte[] receiveData = new byte[1024];
		try {
			ds = new DatagramSocket();
			//InetAddress serverAddr = InetAddress.getByName("130.79.192.146");
			InetAddress serverAddr = InetAddress.getByName("158.130.37.88");
			DatagramPacket sp; //send packet
			DatagramPacket rp; //receive packet
			int i=0;
			while (i<5) {
				
				//udpMsg = "Packet no " + i + "\n";
				char eot = 4;
				udpMsg = "~Hu1"+eot+" "+i+"\n";
				sp = new DatagramPacket(udpMsg.getBytes(), udpMsg.length(),
						serverAddr, UDP_SERVER_PORT);
				ds.send(sp);
				textView.setText(textView.getText() + "\n" + "Sending From client: "+ udpMsg);
				
				rp = new DatagramPacket(receiveData, receiveData.length);
				ds.receive(rp);
				String modifiedSentence = new String(rp.getData(),0,rp.getLength());
				//System.out.println("rp.getLength() " + rp.getLength());
				
				System.out.println("Receiving FROM SERVER:" + modifiedSentence);
				textView.setText(textView.getText() + "\n" + "Receiving from SERVER: " +modifiedSentence); 
				i++;
			}
		} catch (SocketException e) {

			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (ds != null) {
				ds.close();
			}
		}
	}
}