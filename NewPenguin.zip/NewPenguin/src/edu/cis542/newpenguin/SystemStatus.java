package edu.cis542.newpenguin;


import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class SystemStatus extends Activity  implements OnSeekBarChangeListener {
	TextView t1,t2;
	ImageView img1,img2;
	private TextView textProgress;
	private SeekBar bar; // declare seekbar object variable
    
	private static char eot = 4;
	Messenger mService = null;	 
	boolean isBound = false;
	
	
	private static final int ACTIVITY_AuthUsersDisplay= 4;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.v("insideSystem","cool");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.status);
		t1 = (TextView)findViewById(R.id.lightStatus);
		t2 = (TextView)findViewById(R.id.doorStatus);
		img1 = (ImageView)findViewById(R.id.light);
		img2 = (ImageView)findViewById(R.id.door);
		

	    bar = (SeekBar)findViewById(R.id.seekBar1); // make seekbar object
        bar.setOnSeekBarChangeListener(this); // set seekbar listener.
        //bar.setMax(255);
        textProgress = (TextView)findViewById(R.id.progressTxt);
        bindService(new Intent(this,ArduinoSocket.class), mConnection, BIND_AUTO_CREATE);
        
	
	}
	public void onCheckAuthUsersClick(View v)
	{
	Intent i5 = new Intent(this,AuthUsersDisplay.class);
	startActivityForResult(i5,SystemStatus.ACTIVITY_AuthUsersDisplay);
	//adapter.insertString(time,user);
	}

	@Override
	public void onProgressChanged(SeekBar seekbar, int progress, boolean fromUser) {
		// TODO Auto-generated method stub
		
		//Kavi
				
		String ls = Integer.toString(progress);
		
		sendCommand("~Iu0"+ls);
		int li =  (progress*100/255);
		if((li >= 0) && (li <= 10))
		{
			img1.setImageResource(R.drawable.lightoff);
			t1.setText("Light is off");
		}
		else if((li > 10) && (li <= 50))
		{
			img1.setImageResource(R.drawable.lightdim);
			t1.setText("Dim Light");	
		}
		else if((li > 50) && (li <= 90))
		{
			img1.setImageResource(R.drawable.lightbrighter);
			t1.setText("Light is brighter now");	
		}
		else
		{
			img1.setImageResource(R.drawable.lighton);
			t1.setText("Light is on");
		}
		
		String lightDisp = li+"";
		textProgress.setText(lightDisp);
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub
		
	}

	public void onBackClick(View v)
	{

		Intent i6 = new Intent();     	
       	setResult(RESULT_OK, i6);
      	finish();
	
	}

	public void doorClick(View view){
		boolean doorUnlocked = ((ToggleButton) view).isChecked();
		if(!doorUnlocked)
			{
			sendCommand("~Lu00");
			img2.setImageResource(R.drawable.unlock);
			t2.setText("Door is open");
			}
		else 
			{
			sendCommand("~Lu01");
			img2.setImageResource(R.drawable.locked);
			t2.setText("Door is closed");
			}
	}
	
	// Ben start
	public void sendCommand(String message){
		Message msg = Message.obtain(null, ArduinoSocket.UNBIND);
		msg.replyTo = mMessenger;
		Bundle data = new Bundle();
		data.putString("message", message);
		msg.setData(data);
		try {
			mService.send(msg);
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	 class MainHandler extends Handler{
		@Override
		public void handleMessage(Message msg){
			if(msg.what==ArduinoSocket.MESSAGE){
				Log.v("Service Outptut", msg.arg1 + "");
			}
			if(msg.what==ArduinoSocket.REPLY){
				receiveData(msg);
			}
		}
	}
	
	
	final Messenger mMessenger = new Messenger(new MainHandler());

	private ServiceConnection mConnection = new ServiceConnection(){
		public void onServiceConnected(ComponentName className, IBinder service) {
			mService = new Messenger(service);
			
			try {
			Message msg = Message.obtain(null, ArduinoSocket.BIND);
			msg.replyTo = mMessenger;
			mService.send(msg);
			isBound = true;
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				Toast.makeText(SystemStatus.this, "Connection Failed" , Toast.LENGTH_SHORT).show();
			}
			Toast.makeText(SystemStatus.this, "Connected" , Toast.LENGTH_SHORT).show();
		}
		public void onServiceDisconnected(ComponentName className){
			
			mService = null;
			isBound = false;
			
		}
		
	};
	//We need input door and motion!
	public void receiveData(Message msg) {
		Bundle bundle = msg.getData();
		switch (msg.arg1){
		
		case ArduinoSocket.DOOR:
			bundle.getBoolean("door");
			break;
		case ArduinoSocket.MOTION:
			bundle.getBoolean("motion");
			break;
		case ArduinoSocket.LIGHT:
			bar.setProgress(msg.arg2);
			break;
		}
		
	}
	protected void onDestroy(){
		unbindService(mConnection);
		super.onDestroy();
	}
	
	protected void onActivityResult(int requestCode,int resultCode, Intent intent) {
	    super.onActivityResult(requestCode, resultCode, intent);
	    if(requestCode == ACTIVITY_AuthUsersDisplay)
	    {
	      
	    }
	  }
	  

}
