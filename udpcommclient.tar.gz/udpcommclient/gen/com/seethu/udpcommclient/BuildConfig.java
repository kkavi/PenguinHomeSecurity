/** Automatically generated file. DO NOT MODIFY */
package com.seethu.udpcommclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}